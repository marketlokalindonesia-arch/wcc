<?php
// Include helper functions
require_once 'config/helpers.php';

require_once 'config/database.php';
require_once 'models/Product.php';
require_once 'models/Category.php';

// ... kode yang sudah ada
?>